-- =====================================================
-- Database: db_berkahjaya
-- Toko Berkah Jaya - Sistem Manajemen Penjualan
-- =====================================================

CREATE DATABASE IF NOT EXISTS db_berkahjaya
    CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE db_berkahjaya;

-- ===================== TABEL USER =====================
CREATE TABLE IF NOT EXISTS tb_user (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    level VARCHAR(20) NOT NULL DEFAULT 'admin',   -- 'admin' atau 'kasir'
    sedang_login TINYINT(1) NOT NULL DEFAULT 0,
    login_terakhir DATETIME NULL,
    logout_terakhir DATETIME NULL
);

-- ===================== TABEL KATEGORI =====================
CREATE TABLE IF NOT EXISTS tb_kategori (
    id_kategori INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL
);

-- ===================== TABEL BARANG =====================
CREATE TABLE IF NOT EXISTS tb_barang (
    id_barang VARCHAR(20) PRIMARY KEY,
    id_kategori INT NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    satuan VARCHAR(30) NOT NULL,
    harga_jual DOUBLE NOT NULL,
    stok INT NOT NULL,
    FOREIGN KEY (id_kategori) REFERENCES tb_kategori(id_kategori)
);

-- ===================== TABEL CUSTOMER =====================
CREATE TABLE IF NOT EXISTS tb_customer (
    id_customer VARCHAR(20) PRIMARY KEY,
    nama_customer VARCHAR(100) NOT NULL,
    alamat VARCHAR(200),
    telepon VARCHAR(20)
);

-- ===================== TABEL PENJUALAN =====================
CREATE TABLE IF NOT EXISTS tb_penjualan (
    id_jual INT AUTO_INCREMENT PRIMARY KEY,
    tgl_transaksi DATE NOT NULL,
    id_customer VARCHAR(20) NOT NULL,
    id_barang VARCHAR(20) NOT NULL,
    jumlah_beli INT NOT NULL,
    total_bayar DOUBLE NOT NULL,
    id_user INT NOT NULL,
    FOREIGN KEY (id_customer) REFERENCES tb_customer(id_customer),
    FOREIGN KEY (id_barang) REFERENCES tb_barang(id_barang),
    FOREIGN KEY (id_user) REFERENCES tb_user(id_user)
);

-- ===================== DATA AWAL: USER =====================
-- Password disimpan plain text agar sesuai contoh "Demo: admin / admin123"
-- (untuk produksi sebaiknya di-hash, lihat saran pengembangan di laporan)
INSERT INTO tb_user (username, password, nama_lengkap, level) VALUES
('admin', 'admin123', 'Administrator', 'admin'),
('kasir', 'kasir123', 'Petugas Kasir', 'kasir');

-- ===================== DATA AWAL: KATEGORI =====================
INSERT INTO tb_kategori (nama_kategori) VALUES
('Elektronik'),
('Makanan'),
('Alat Tulis'),
('Pakaian'),
('Peralatan');

-- ===================== DATA AWAL: BARANG =====================
INSERT INTO tb_barang (id_barang, id_kategori, nama_barang, satuan, harga_jual, stok) VALUES
('BRG001', 1, 'Kipas Angin Miyako', 'Unit', 285000, 10),
('BRG002', 1, 'Lampu LED Philips', 'Buah', 45000, 50),
('BRG003', 2, 'Aqua Galon 19L', 'Galon', 20000, 23),
('BRG004', 2, 'Mie Instan Indomie', 'Dus', 85000, 32),
('BRG005', 3, 'Pulpen Pilot G2', 'Lusin', 36000, 60),
('BRG006', 3, 'Buku Tulis Sinar Dunia', 'Lusin', 48000, 35),
('BRG007', 4, 'Kaos Polos Cotton', 'Pcs', 75000, 25),
('BRG008', 5, 'Sapu Lantai Baja', 'Buah', 35000, 20),
('BRG009', 3, 'Panji Alat Tulis', 'Buku', 25000, 12),
('BRG010', 3, 'Roki Alat Tulis', 'Buku', 50000, 15);

-- ===================== DATA AWAL: CUSTOMER =====================
INSERT INTO tb_customer (id_customer, nama_customer, alamat, telepon) VALUES
('CST001', 'Budi Santoso', 'Jl. Merdeka No.12 Jakarta', '081234567890'),
('CST002', 'Siti Rahayu', 'Jl. Sudirman No.45 Bandung', '082345678901'),
('CST003', 'Ahmad Fauzi', 'Jl. Diponegoro No.7 Surabaya', '083456789012'),
('CST004', 'Dewi Lestari', 'Jl. Gajah Mada No.33 Medan', '084567890123'),
('CST005', 'Eko Prasetyo', 'Jl. Ahmad Yani No.19 Semarang', '085678901234'),
('CST006', 'roky', 'Jl. ompong no 1', '081299912345'),
('CST007', '91091201', 'Jl pamulang no 1', 'adbasdba');

-- ===================== DATA AWAL: PENJUALAN (sample, sesuai laporan) =====================
INSERT INTO tb_penjualan (tgl_transaksi, id_customer, id_barang, jumlah_beli, total_bayar, id_user) VALUES
('2026-05-28', 'CST003', 'BRG003', 7, 140000, 1),
('2026-06-19', 'CST001', 'BRG001', 5, 1425000, 1),
('2026-06-19', 'CST006', 'BRG004', 8, 680000, 1);
