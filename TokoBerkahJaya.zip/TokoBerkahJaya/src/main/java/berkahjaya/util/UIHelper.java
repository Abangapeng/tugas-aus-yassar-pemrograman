package berkahjaya.util;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Kumpulan helper UI: palet warna konsisten dan format mata uang Rupiah,
 * dipakai bersama oleh seluruh panel (Dashboard, Barang, Customer, Transaksi, Laporan).
 */
public class UIHelper {

    // ===== Palet Warna =====
    public static final Color C_BG        = new Color(240, 242, 247);
    public static final Color C_WHITE     = Color.WHITE;
    public static final Color C_NAVY      = new Color(25, 55, 110);
    public static final Color C_BLUE_LT   = new Color(52, 152, 219);
    public static final Color C_GREEN     = new Color(46, 204, 113);
    public static final Color C_ORANGE    = new Color(243, 156, 18);
    public static final Color C_RED       = new Color(231, 76, 60);
    public static final Color C_TEAL      = new Color(26, 188, 156);
    public static final Color C_TEXT_MUTED= new Color(120, 130, 150);
    public static final Color C_ROW_ALT   = new Color(248, 249, 252);

    private static final NumberFormat RUPIAH_FORMAT;
    static {
        RUPIAH_FORMAT = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        RUPIAH_FORMAT.setMaximumFractionDigits(0);
    }

    /** Format angka menjadi string Rupiah, contoh: 285000 -> "Rp 285.000" */
    public static String rupiah(double value) {
        String s = RUPIAH_FORMAT.format(value);
        // NumberFormat default menghasilkan "Rp285.000", tambahkan spasi agar rapi
        return s.replace("Rp", "Rp ");
    }
}
