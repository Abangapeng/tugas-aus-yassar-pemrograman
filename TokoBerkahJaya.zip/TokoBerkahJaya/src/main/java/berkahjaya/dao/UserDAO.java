package berkahjaya.dao;

import berkahjaya.model.User;
import berkahjaya.util.DBConnection;

import java.sql.*;

public class UserDAO {

    /** Cek username & password, update status sedang_login + login_terakhir jika berhasil. */
    public User login(String username, String password) throws SQLException {
        String sql = "SELECT * FROM tb_user WHERE username=? AND password=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = new User(
                            rs.getInt("id_user"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("nama_lengkap"),
                            rs.getString("level")
                    );
                    updateLoginStatus(u.getIdUser(), true);
                    return u;
                }
            }
        }
        return null;
    }

    public void logout(int idUser) throws SQLException {
        updateLoginStatus(idUser, false);
    }

    private void updateLoginStatus(int idUser, boolean login) throws SQLException {
        String sql = login
                ? "UPDATE tb_user SET sedang_login=1, login_terakhir=NOW() WHERE id_user=?"
                : "UPDATE tb_user SET sedang_login=0, logout_terakhir=NOW() WHERE id_user=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUser);
            ps.executeUpdate();
        }
    }
}
