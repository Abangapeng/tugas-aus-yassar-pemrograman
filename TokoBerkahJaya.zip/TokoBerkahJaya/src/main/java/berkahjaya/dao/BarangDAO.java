package berkahjaya.dao;

import berkahjaya.model.Barang;
import berkahjaya.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BarangDAO {

    public List<Barang> getAll() throws SQLException {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT b.*, k.nama_kategori FROM tb_barang b " +
                     "JOIN tb_kategori k ON b.id_kategori = k.id_kategori " +
                     "ORDER BY b.id_barang";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    public List<Barang> search(String keyword) throws SQLException {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT b.*, k.nama_kategori FROM tb_barang b " +
                     "JOIN tb_kategori k ON b.id_kategori = k.id_kategori " +
                     "WHERE LOWER(b.nama_barang) LIKE ? OR LOWER(b.id_barang) LIKE ? " +
                     "ORDER BY b.id_barang";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String q = "%" + keyword.toLowerCase() + "%";
            ps.setString(1, q);
            ps.setString(2, q);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public void insert(Barang b) throws SQLException {
        String sql = "INSERT INTO tb_barang (id_barang, id_kategori, nama_barang, satuan, harga_jual, stok) " +
                     "VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, b.getIdBarang());
            ps.setInt(2, b.getIdKategori());
            ps.setString(3, b.getNamaBarang());
            ps.setString(4, b.getSatuan());
            ps.setDouble(5, b.getHargaJual());
            ps.setInt(6, b.getStok());
            ps.executeUpdate();
        }
    }

    public void update(Barang b) throws SQLException {
        String sql = "UPDATE tb_barang SET id_kategori=?, nama_barang=?, satuan=?, harga_jual=?, stok=? " +
                     "WHERE id_barang=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, b.getIdKategori());
            ps.setString(2, b.getNamaBarang());
            ps.setString(3, b.getSatuan());
            ps.setDouble(4, b.getHargaJual());
            ps.setInt(5, b.getStok());
            ps.setString(6, b.getIdBarang());
            ps.executeUpdate();
        }
    }

    public void delete(String idBarang) throws SQLException {
        String sql = "DELETE FROM tb_barang WHERE id_barang=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, idBarang);
            ps.executeUpdate();
        }
    }

    /** Kurangi stok setelah transaksi berhasil. */
    public void kurangiStok(String idBarang, int jumlah) throws SQLException {
        String sql = "UPDATE tb_barang SET stok = stok - ? WHERE id_barang=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, jumlah);
            ps.setString(2, idBarang);
            ps.executeUpdate();
        }
    }

    public String generateNextId() throws SQLException {
        String sql = "SELECT id_barang FROM tb_barang ORDER BY id_barang DESC LIMIT 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String last = rs.getString("id_barang"); // contoh: BRG010
                int num = Integer.parseInt(last.replaceAll("\\D+", ""));
                return String.format("BRG%03d", num + 1);
            }
        }
        return "BRG001";
    }

    private Barang map(ResultSet rs) throws SQLException {
        Barang b = new Barang(
                rs.getString("id_barang"),
                rs.getInt("id_kategori"),
                rs.getString("nama_barang"),
                rs.getString("satuan"),
                rs.getDouble("harga_jual"),
                rs.getInt("stok")
        );
        b.setNamaKategori(rs.getString("nama_kategori"));
        return b;
    }
}
