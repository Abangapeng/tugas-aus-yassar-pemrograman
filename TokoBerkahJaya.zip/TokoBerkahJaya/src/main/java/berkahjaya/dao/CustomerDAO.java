package berkahjaya.dao;

import berkahjaya.model.Customer;
import berkahjaya.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {

    public List<Customer> getAll() throws SQLException {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM tb_customer ORDER BY id_customer";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public void insert(Customer c) throws SQLException {
        String sql = "INSERT INTO tb_customer (id_customer, nama_customer, alamat, telepon) VALUES (?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getIdCustomer());
            ps.setString(2, c.getNamaCustomer());
            ps.setString(3, c.getAlamat());
            ps.setString(4, c.getTelepon());
            ps.executeUpdate();
        }
    }

    public void update(Customer c) throws SQLException {
        String sql = "UPDATE tb_customer SET nama_customer=?, alamat=?, telepon=? WHERE id_customer=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNamaCustomer());
            ps.setString(2, c.getAlamat());
            ps.setString(3, c.getTelepon());
            ps.setString(4, c.getIdCustomer());
            ps.executeUpdate();
        }
    }

    public void delete(String idCustomer) throws SQLException {
        String sql = "DELETE FROM tb_customer WHERE id_customer=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, idCustomer);
            ps.executeUpdate();
        }
    }

    public String generateNextId() throws SQLException {
        String sql = "SELECT id_customer FROM tb_customer ORDER BY id_customer DESC LIMIT 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String last = rs.getString("id_customer"); // contoh: CST007
                int num = Integer.parseInt(last.replaceAll("\\D+", ""));
                return String.format("CST%03d", num + 1);
            }
        }
        return "CST001";
    }

    private Customer map(ResultSet rs) throws SQLException {
        return new Customer(
                rs.getString("id_customer"),
                rs.getString("nama_customer"),
                rs.getString("alamat"),
                rs.getString("telepon")
        );
    }
}
