package berkahjaya.dao;

import berkahjaya.model.Penjualan;
import berkahjaya.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PenjualanDAO {

    /**
     * Simpan transaksi penjualan dan kurangi stok barang dalam satu transaction.
     * Jika stok tidak cukup, batalkan (rollback) dan lempar SQLException.
     */
    public void simpanTransaksi(Penjualan p) throws SQLException {
        Connection con = DBConnection.getConnection();
        try {
            con.setAutoCommit(false);

            // Cek stok terbaru & kurangi
            String cekSql = "SELECT stok FROM tb_barang WHERE id_barang=? FOR UPDATE";
            int stokSekarang;
            try (PreparedStatement ps = con.prepareStatement(cekSql)) {
                ps.setString(1, p.getIdBarang());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Barang tidak ditemukan.");
                    stokSekarang = rs.getInt("stok");
                }
            }
            if (stokSekarang < p.getJumlahBeli()) {
                throw new SQLException("Stok tidak cukup. Sisa stok: " + stokSekarang);
            }

            String insertSql = "INSERT INTO tb_penjualan (tgl_transaksi, id_customer, id_barang, jumlah_beli, total_bayar, id_user) " +
                                "VALUES (?,?,?,?,?,?)";
            try (PreparedStatement ps = con.prepareStatement(insertSql)) {
                ps.setDate(1, new java.sql.Date(p.getTglTransaksi().getTime()));
                ps.setString(2, p.getIdCustomer());
                ps.setString(3, p.getIdBarang());
                ps.setInt(4, p.getJumlahBeli());
                ps.setDouble(5, p.getTotalBayar());
                ps.setInt(6, p.getIdUser());
                ps.executeUpdate();
            }

            String updateStokSql = "UPDATE tb_barang SET stok = stok - ? WHERE id_barang=?";
            try (PreparedStatement ps = con.prepareStatement(updateStokSql)) {
                ps.setInt(1, p.getJumlahBeli());
                ps.setString(2, p.getIdBarang());
                ps.executeUpdate();
            }

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
        }
    }

    /** Ambil seluruh laporan transaksi (join customer, barang, user), terbaru di atas. */
    public List<Penjualan> getLaporan() throws SQLException {
        List<Penjualan> list = new ArrayList<>();
        String sql = "SELECT pj.*, c.nama_customer, b.nama_barang, b.harga_jual, u.nama_lengkap " +
                     "FROM tb_penjualan pj " +
                     "JOIN tb_customer c ON pj.id_customer = c.id_customer " +
                     "JOIN tb_barang b ON pj.id_barang = b.id_barang " +
                     "JOIN tb_user u ON pj.id_user = u.id_user " +
                     "ORDER BY pj.id_jual DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Penjualan p = new Penjualan();
                p.setIdJual(rs.getInt("id_jual"));
                p.setTglTransaksi(rs.getDate("tgl_transaksi"));
                p.setIdCustomer(rs.getString("id_customer"));
                p.setNamaCustomer(rs.getString("nama_customer"));
                p.setIdBarang(rs.getString("id_barang"));
                p.setNamaBarang(rs.getString("nama_barang"));
                p.setHargaJual(rs.getDouble("harga_jual"));
                p.setJumlahBeli(rs.getInt("jumlah_beli"));
                p.setTotalBayar(rs.getDouble("total_bayar"));
                p.setIdUser(rs.getInt("id_user"));
                p.setNamaUser(rs.getString("nama_lengkap"));
                list.add(p);
            }
        }
        return list;
    }

    public double getTotalPendapatan() throws SQLException {
        String sql = "SELECT COALESCE(SUM(total_bayar),0) AS total FROM tb_penjualan";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble("total");
        }
        return 0;
    }
}
