package berkahjaya.model;

import java.util.Date;

public class Penjualan {
    private int idJual;
    private Date tglTransaksi;
    private String idCustomer;
    private String namaCustomer; // hasil join
    private String idBarang;
    private String namaBarang;   // hasil join
    private double hargaJual;    // hasil join (harga satuan saat itu)
    private int jumlahBeli;
    private double totalBayar;
    private int idUser;
    private String namaUser;     // hasil join

    public Penjualan() {}

    public Penjualan(Date tglTransaksi, String idCustomer, String idBarang,
                      int jumlahBeli, double totalBayar, int idUser) {
        this.tglTransaksi = tglTransaksi;
        this.idCustomer = idCustomer;
        this.idBarang = idBarang;
        this.jumlahBeli = jumlahBeli;
        this.totalBayar = totalBayar;
        this.idUser = idUser;
    }

    public int getIdJual() { return idJual; }
    public void setIdJual(int idJual) { this.idJual = idJual; }

    public Date getTglTransaksi() { return tglTransaksi; }
    public void setTglTransaksi(Date tglTransaksi) { this.tglTransaksi = tglTransaksi; }

    public String getIdCustomer() { return idCustomer; }
    public void setIdCustomer(String idCustomer) { this.idCustomer = idCustomer; }

    public String getNamaCustomer() { return namaCustomer; }
    public void setNamaCustomer(String namaCustomer) { this.namaCustomer = namaCustomer; }

    public String getIdBarang() { return idBarang; }
    public void setIdBarang(String idBarang) { this.idBarang = idBarang; }

    public String getNamaBarang() { return namaBarang; }
    public void setNamaBarang(String namaBarang) { this.namaBarang = namaBarang; }

    public double getHargaJual() { return hargaJual; }
    public void setHargaJual(double hargaJual) { this.hargaJual = hargaJual; }

    public int getJumlahBeli() { return jumlahBeli; }
    public void setJumlahBeli(int jumlahBeli) { this.jumlahBeli = jumlahBeli; }

    public double getTotalBayar() { return totalBayar; }
    public void setTotalBayar(double totalBayar) { this.totalBayar = totalBayar; }

    public int getIdUser() { return idUser; }
    public void setIdUser(int idUser) { this.idUser = idUser; }

    public String getNamaUser() { return namaUser; }
    public void setNamaUser(String namaUser) { this.namaUser = namaUser; }
}
