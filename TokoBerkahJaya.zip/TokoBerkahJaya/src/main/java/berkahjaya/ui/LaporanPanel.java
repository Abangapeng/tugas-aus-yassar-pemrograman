package berkahjaya.ui;

import berkahjaya.dao.PenjualanDAO;
import berkahjaya.model.Penjualan;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

public class LaporanPanel extends JPanel {

    private final PenjualanDAO dao = new PenjualanDAO();
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblTotal, lblJumlah;

    public LaporanPanel() {
        setBackground(UIHelper.C_BG);
        setLayout(new BorderLayout());
        build();
        load();
    }

    private void build() {
        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setBackground(UIHelper.C_BG);
        content.setBorder(new EmptyBorder(25, 25, 25, 25));

        content.add(buildSummary(), BorderLayout.NORTH);
        content.add(buildTable(), BorderLayout.CENTER);

        add(content, BorderLayout.CENTER);
    }

    private JPanel buildSummary() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 20, 0));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

        panel.add(summaryCard("TOTAL TRANSAKSI", UIHelper.C_BLUE_LT, true));
        panel.add(summaryCard("TOTAL PENDAPATAN", UIHelper.C_GREEN, false));
        return panel;
    }

    private JPanel summaryCard(String title, Color color, boolean isCount) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 240)));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(color);
        header.setBorder(new EmptyBorder(10, 18, 10, 18));
        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLbl.setForeground(Color.WHITE);
        header.add(titleLbl, BorderLayout.WEST);
        card.add(header, BorderLayout.NORTH);

        JLabel valueLbl = new JLabel("0", SwingConstants.CENTER);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLbl.setForeground(color);
        valueLbl.setBorder(new EmptyBorder(16, 0, 16, 0));
        card.add(valueLbl, BorderLayout.CENTER);

        if (isCount) lblJumlah = valueLbl; else lblTotal = valueLbl;
        return card;
    }

    private JPanel buildTable() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 240)));

        JLabel header = new JLabel("  Riwayat Transaksi Penjualan");
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setForeground(UIHelper.C_NAVY);
        header.setBorder(new EmptyBorder(14, 8, 14, 8));
        card.add(header, BorderLayout.NORTH);

        String[] cols = {"No", "ID", "Tanggal", "Customer", "Barang", "Harga Satuan", "Jumlah", "Total Bayar", "Kasir"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);
        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    private void load() {
        try {
            populate(dao.getLaporan());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat laporan: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populate(List<Penjualan> list) {
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        double grand = 0;
        int no = 1;
        for (Penjualan p : list) {
            tableModel.addRow(new Object[]{
                    no++, p.getIdJual(), sdf.format(p.getTglTransaksi()), p.getNamaCustomer(),
                    p.getNamaBarang(), UIHelper.rupiah(p.getHargaJual()), p.getJumlahBeli(),
                    UIHelper.rupiah(p.getTotalBayar()), p.getNamaUser()
            });
            grand += p.getTotalBayar();
        }
        lblJumlah.setText(String.valueOf(list.size()));
        lblTotal.setText(UIHelper.rupiah(grand));
    }
}
