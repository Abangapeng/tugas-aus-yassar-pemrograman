package berkahjaya.ui;

import berkahjaya.dao.BarangDAO;
import berkahjaya.dao.CustomerDAO;
import berkahjaya.dao.PenjualanDAO;
import berkahjaya.model.Penjualan;
import berkahjaya.model.User;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class DashboardPanel extends JPanel {

    private final User user;

    public DashboardPanel(User user) {
        this.user = user;
        setBackground(UIHelper.C_BG);
        setLayout(new BorderLayout());
        JScrollPane scroll = new JScrollPane(buildContent());
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);
    }

    private JPanel buildContent() {
        JPanel content = new JPanel();
        content.setBackground(UIHelper.C_BG);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(25, 25, 25, 25));

        content.add(buildHeader());
        content.add(Box.createVerticalStrut(20));

        int totalBarang = 0, totalCustomer = 0, totalTrx = 0, stokRendah = 0;
        double totalPendapatan = 0;
        List<Penjualan> recent = new ArrayList<>();
        try {
            totalBarang = new BarangDAO().getAll().size();
            totalCustomer = new CustomerDAO().getAll().size();
            List<Penjualan> all = new PenjualanDAO().getLaporan();
            totalTrx = all.size();
            totalPendapatan = new PenjualanDAO().getTotalPendapatan();
            for (int i = 0; i < Math.min(6, all.size()); i++) recent.add(all.get(i));
            stokRendah = (int) new BarangDAO().getAll().stream().filter(b -> b.getStok() <= 5).count();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data dashboard:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        JPanel row1 = new JPanel(new GridLayout(1, 4, 15, 0));
        row1.setOpaque(false);
        row1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        row1.add(statCard(String.valueOf(totalBarang), "Semua Produk", "Total Inventory", UIHelper.C_BLUE_LT));
        row1.add(statCard(String.valueOf(totalCustomer), "Total Customer", "Registered Members", UIHelper.C_GREEN));
        row1.add(statCard(String.valueOf(totalTrx), "Semua Trx Penjualan", "All Transactions", UIHelper.C_ORANGE));
        row1.add(statCard(String.valueOf(stokRendah), "Produk Stok Menipis", "Need Restock", UIHelper.C_RED));
        content.add(row1);
        content.add(Box.createVerticalStrut(15));

        JPanel row2 = new JPanel(new GridLayout(1, 2, 15, 0));
        row2.setOpaque(false);
        row2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        row2.add(statCard(UIHelper.rupiah(totalPendapatan), "Total Semua Penjualan", "Lifetime Revenue", UIHelper.C_NAVY));
        row2.add(statCard(UIHelper.rupiah(todayRevenue(recent)), "Penjualan Hari Ini", "Today's Sales", UIHelper.C_TEAL));
        content.add(row2);
        content.add(Box.createVerticalStrut(20));

        content.add(buildRecentTable(recent));

        return content;
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        String greeting = getGreeting();
        JLabel title = new JLabel(greeting + ", " + user.getNamaLengkap() + "!");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(UIHelper.C_NAVY);

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", new Locale("id", "ID")));
        JLabel dateLbl = new JLabel(today);
        dateLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        dateLbl.setForeground(UIHelper.C_TEXT_MUTED);

        header.add(title, BorderLayout.WEST);
        header.add(dateLbl, BorderLayout.EAST);
        return header;
    }

    private String getGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Selamat Pagi";
        if (hour < 15) return "Selamat Siang";
        if (hour < 18) return "Selamat Sore";
        return "Selamat Malam";
    }

    private JPanel statCard(String value, String title, String subtitle, Color accent) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel valueLbl = new JLabel(value);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        valueLbl.setForeground(new Color(45, 55, 75));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLbl.setForeground(new Color(80, 90, 110));

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        subLbl.setForeground(UIHelper.C_TEXT_MUTED);

        card.add(valueLbl);
        card.add(Box.createVerticalStrut(6));
        card.add(titleLbl);
        card.add(subLbl);
        return card;
    }

    private JPanel buildRecentTable(List<Penjualan> list) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 240)));

        JLabel header = new JLabel("  Transaksi Terakhir");
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setForeground(UIHelper.C_NAVY);
        header.setBorder(new EmptyBorder(12, 8, 12, 8));
        card.add(header, BorderLayout.NORTH);

        String[] cols = {"Tanggal", "Customer", "Barang", "Total"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (Penjualan p : list) {
            m.addRow(new Object[]{sdf.format(p.getTglTransaksi()), p.getNamaCustomer(), p.getNamaBarang(), UIHelper.rupiah(p.getTotalBayar())});
        }
        if (list.isEmpty()) m.addRow(new Object[]{"-", "Belum ada transaksi", "", ""});

        JTable table = new JTable(m);
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JScrollPane sp = new JScrollPane(table);
        sp.setPreferredSize(new Dimension(0, 220));
        card.add(sp, BorderLayout.CENTER);

        return card;
    }

    private double todayRevenue(List<Penjualan> list) {
        String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        return list.stream()
                .filter(p -> new SimpleDateFormat("yyyy-MM-dd").format(p.getTglTransaksi()).equals(today))
                .mapToDouble(Penjualan::getTotalBayar).sum();
    }
}
