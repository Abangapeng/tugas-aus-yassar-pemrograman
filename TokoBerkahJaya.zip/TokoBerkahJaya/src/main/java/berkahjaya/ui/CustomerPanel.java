package berkahjaya.ui;

import berkahjaya.dao.CustomerDAO;
import berkahjaya.model.Customer;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class CustomerPanel extends JPanel {

    private final CustomerDAO dao = new CustomerDAO();
    private JTextField tfId, tfNama, tfAlamat, tfTelepon, tfSearch;
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnSimpan, btnUpdate, btnHapus, btnBatal;

    public CustomerPanel() {
        setBackground(UIHelper.C_BG);
        setLayout(new BorderLayout());
        build();
        loadTable();
    }

    private void build() {
        JPanel content = new JPanel(new BorderLayout(18, 0));
        content.setBackground(UIHelper.C_BG);
        content.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel formCard = card();
        formCard.setPreferredSize(new Dimension(300, 0));
        formCard.add(cardHeader("Form Data Customer"), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(15, 15, 15, 15));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        g.insets = new Insets(5, 0, 5, 0);

        tfId = field(); tfId.setEditable(false); tfId.setBackground(new Color(245, 247, 250));
        tfNama = field();
        tfAlamat = field();
        tfTelepon = field();

        addField(form, g, 0, "ID Customer (Otomatis)", tfId);
        addField(form, g, 1, "Nama Customer *", tfNama);
        addField(form, g, 2, "Alamat", tfAlamat);
        addField(form, g, 3, "No. Telepon", tfTelepon);

        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
        btnGrid.setOpaque(false);
        btnGrid.setBorder(new EmptyBorder(15, 0, 0, 0));
        btnSimpan = btn("Simpan", UIHelper.C_GREEN);
        btnUpdate = btn("Update", UIHelper.C_BLUE_LT);
        btnHapus = btn("Hapus", UIHelper.C_RED);
        btnBatal = btn("Batal", new Color(149, 165, 166));
        btnUpdate.setEnabled(false);
        btnHapus.setEnabled(false);
        btnGrid.add(btnSimpan); btnGrid.add(btnUpdate); btnGrid.add(btnHapus); btnGrid.add(btnBatal);

        g.gridx = 0; g.gridy = 8; g.gridwidth = 2;
        form.add(btnGrid, g);
        formCard.add(form, BorderLayout.CENTER);

        JPanel tableCard = card();
        JPanel tableHeader = cardHeader("Daftar Customer");
        JPanel searchBar = new JPanel(new BorderLayout(8, 0));
        searchBar.setOpaque(false);
        searchBar.setBorder(new EmptyBorder(8, 16, 8, 16));
        tfSearch = field();
        JButton btnRefresh = btn("Cari/Refresh", UIHelper.C_BLUE_LT);
        searchBar.add(new JLabel("Cari: "), BorderLayout.WEST);
        searchBar.add(tfSearch, BorderLayout.CENTER);
        searchBar.add(btnRefresh, BorderLayout.EAST);
        tableHeader.add(searchBar, BorderLayout.SOUTH);
        tableCard.add(tableHeader, BorderLayout.NORTH);

        String[] cols = {"ID Customer", "Nama Customer", "Alamat", "No. Telepon"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);
        tableCard.add(scroll, BorderLayout.CENTER);

        content.add(formCard, BorderLayout.WEST);
        content.add(tableCard, BorderLayout.CENTER);
        add(content, BorderLayout.CENTER);

        btnSimpan.addActionListener(e -> doInsert());
        btnUpdate.addActionListener(e -> doUpdate());
        btnHapus.addActionListener(e -> doDelete());
        btnBatal.addActionListener(e -> resetForm());
        btnRefresh.addActionListener(e -> doSearch());
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) fillForm();
        });
    }

    private JPanel card() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 240)));
        return p;
    }

    private JPanel cardHeader(String title) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(248, 251, 255));
        header.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(UIHelper.C_NAVY);
        header.add(lbl, BorderLayout.WEST);
        return header;
    }

    private JTextField field() {
        JTextField f = new JTextField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 225)),
                new EmptyBorder(6, 8, 6, 8)));
        return f;
    }

    private JButton btn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.BOLD, 11));
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void addField(JPanel panel, GridBagConstraints g, int row, String label, JComponent field) {
        g.gridx = 0; g.gridy = row * 2; g.gridwidth = 2;
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(new Color(80, 90, 110));
        panel.add(l, g);
        g.gridy = row * 2 + 1;
        panel.add(field, g);
    }

    private void loadTable() {
        try {
            tableModel.setRowCount(0);
            for (Customer c : dao.getAll()) addRow(c);
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void doSearch() {
        String q = tfSearch.getText().toLowerCase().trim();
        try {
            tableModel.setRowCount(0);
            for (Customer c : dao.getAll()) {
                if (q.isEmpty() || c.getNamaCustomer().toLowerCase().contains(q)
                        || c.getIdCustomer().toLowerCase().contains(q)) {
                    addRow(c);
                }
            }
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void addRow(Customer c) {
        tableModel.addRow(new Object[]{
                c.getIdCustomer(), c.getNamaCustomer(),
                c.getAlamat() != null ? c.getAlamat() : "",
                c.getTelepon() != null ? c.getTelepon() : ""
        });
    }

    private void fillForm() {
        int r = table.getSelectedRow();
        tfId.setText(tableModel.getValueAt(r, 0).toString());
        tfNama.setText(tableModel.getValueAt(r, 1).toString());
        tfAlamat.setText(tableModel.getValueAt(r, 2).toString());
        tfTelepon.setText(tableModel.getValueAt(r, 3).toString());
        btnSimpan.setEnabled(false);
        btnUpdate.setEnabled(true);
        btnHapus.setEnabled(true);
    }

    private boolean validInput() {
        if (tfNama.getText().trim().isEmpty()) {
            err("Nama Customer harus diisi!");
            return false;
        }
        return true;
    }

    private Customer fromForm() {
        return new Customer(tfId.getText().trim(), tfNama.getText().trim(),
                tfAlamat.getText().trim(), tfTelepon.getText().trim());
    }

    private void doInsert() {
        if (!validInput()) return;
        try {
            Customer c = fromForm();
            c.setIdCustomer(dao.generateNextId());
            dao.insert(c);
            ok("Customer berhasil disimpan!");
            resetForm();
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void doUpdate() {
        if (!validInput()) return;
        try {
            dao.update(fromForm());
            ok("Data berhasil diperbarui!");
            resetForm();
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void doDelete() {
        String id = tfId.getText();
        if (id.isEmpty()) return;
        if (JOptionPane.showConfirmDialog(this, "Hapus customer " + id + "?", "Konfirmasi",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            dao.delete(id);
            ok("Customer berhasil dihapus!");
            resetForm();
        } catch (SQLException ex) {
            err("Gagal hapus (mungkin sudah memiliki transaksi): " + ex.getMessage());
        }
    }

    private void resetForm() {
        tfId.setText(""); tfNama.setText(""); tfAlamat.setText("");
        tfTelepon.setText(""); tfSearch.setText("");
        btnSimpan.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnHapus.setEnabled(false);
        table.clearSelection();
        loadTable();
    }

    private void ok(String m) { JOptionPane.showMessageDialog(this, m, "Sukses", JOptionPane.INFORMATION_MESSAGE); }
    private void err(String m) { JOptionPane.showMessageDialog(this, m, "Error", JOptionPane.ERROR_MESSAGE); }
}
