package berkahjaya.ui;

import berkahjaya.dao.BarangDAO;
import berkahjaya.dao.KategoriDAO;
import berkahjaya.model.Barang;
import berkahjaya.model.Kategori;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class BarangPanel extends JPanel {

    private final BarangDAO dao = new BarangDAO();
    private final KategoriDAO kategoriDAO = new KategoriDAO();

    private JTextField tfId, tfNama, tfSatuan, tfHarga, tfStok, tfSearch;
    private JComboBox<Kategori> cbKategori;
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnSimpan, btnUpdate, btnHapus, btnBatal;

    public BarangPanel() {
        setBackground(UIHelper.C_BG);
        setLayout(new BorderLayout());
        build();
        loadKategori();
        loadTable();
    }

    private void build() {
        JPanel content = new JPanel(new BorderLayout(18, 0));
        content.setBackground(UIHelper.C_BG);
        content.setBorder(new EmptyBorder(20, 20, 20, 20));

        // ===== FORM (kiri) =====
        JPanel formCard = card();
        formCard.setPreferredSize(new Dimension(300, 0));
        formCard.add(cardHeader("Form Data Barang"), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(15, 15, 15, 15));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        g.insets = new Insets(5, 0, 5, 0);

        tfId = field(); tfId.setEditable(false); tfId.setBackground(new Color(245, 247, 250));
        tfNama = field();
        cbKategori = new JComboBox<>();
        tfSatuan = field();
        tfHarga = field();
        tfStok = field();

        int row = 0;
        addField(form, g, row++, "ID Barang (Otomatis)", tfId);
        addField(form, g, row++, "Nama Barang *", tfNama);
        addField(form, g, row++, "Kategori *", cbKategori);
        addField(form, g, row++, "Satuan *", tfSatuan);
        addField(form, g, row++, "Harga Jual *", tfHarga);
        addField(form, g, row++, "Stok *", tfStok);

        JPanel btnGrid = new JPanel(new GridLayout(2, 2, 8, 8));
        btnGrid.setOpaque(false);
        btnGrid.setBorder(new EmptyBorder(15, 0, 0, 0));
        btnSimpan = btn("Simpan", UIHelper.C_GREEN);
        btnUpdate = btn("Update", UIHelper.C_BLUE_LT);
        btnHapus = btn("Hapus", UIHelper.C_RED);
        btnBatal = btn("Batal", new Color(149, 165, 166));
        btnUpdate.setEnabled(false);
        btnHapus.setEnabled(false);
        btnGrid.add(btnSimpan); btnGrid.add(btnUpdate); btnGrid.add(btnHapus); btnGrid.add(btnBatal);

        g.gridx = 0; g.gridy = row; g.gridwidth = 2;
        form.add(btnGrid, g);
        formCard.add(form, BorderLayout.CENTER);

        // ===== TABEL (kanan) =====
        JPanel tableCard = card();
        JPanel tableHeader = cardHeader("Daftar Barang");
        JPanel searchBar = new JPanel(new BorderLayout(8, 0));
        searchBar.setOpaque(false);
        searchBar.setBorder(new EmptyBorder(8, 16, 8, 16));
        tfSearch = field();
        JButton btnRefresh = btn("Cari/Refresh", UIHelper.C_BLUE_LT);
        searchBar.add(new JLabel("Cari: "), BorderLayout.WEST);
        searchBar.add(tfSearch, BorderLayout.CENTER);
        searchBar.add(btnRefresh, BorderLayout.EAST);
        tableHeader.add(searchBar, BorderLayout.SOUTH);
        tableCard.add(tableHeader, BorderLayout.NORTH);

        String[] cols = {"ID Barang", "Nama Barang", "Kategori", "Satuan", "Harga Jual", "Stok"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);
        tableCard.add(scroll, BorderLayout.CENTER);

        content.add(formCard, BorderLayout.WEST);
        content.add(tableCard, BorderLayout.CENTER);
        add(content, BorderLayout.CENTER);

        // Events
        btnSimpan.addActionListener(e -> doInsert());
        btnUpdate.addActionListener(e -> doUpdate());
        btnHapus.addActionListener(e -> doDelete());
        btnBatal.addActionListener(e -> resetForm());
        btnRefresh.addActionListener(e -> doSearch());
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) fillForm();
        });
    }

    private JPanel card() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 240)));
        return p;
    }

    private JPanel cardHeader(String title) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(248, 251, 255));
        header.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(UIHelper.C_NAVY);
        header.add(lbl, BorderLayout.WEST);
        return header;
    }

    private JTextField field() {
        JTextField f = new JTextField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 225)),
                new EmptyBorder(6, 8, 6, 8)));
        return f;
    }

    private JButton btn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.BOLD, 11));
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void addField(JPanel panel, GridBagConstraints g, int row, String label, JComponent field) {
        g.gridx = 0; g.gridy = row * 2; g.gridwidth = 2;
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(new Color(80, 90, 110));
        panel.add(l, g);
        g.gridy = row * 2 + 1;
        panel.add(field, g);
    }

    private void loadKategori() {
        try {
            cbKategori.removeAllItems();
            for (Kategori k : kategoriDAO.getAll()) cbKategori.addItem(k);
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void loadTable() {
        try {
            populate(dao.getAll());
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void doSearch() {
        String q = tfSearch.getText().trim();
        try {
            populate(q.isEmpty() ? dao.getAll() : dao.search(q));
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void populate(List<Barang> list) {
        tableModel.setRowCount(0);
        for (Barang b : list) {
            tableModel.addRow(new Object[]{
                    b.getIdBarang(), b.getNamaBarang(), b.getNamaKategori(),
                    b.getSatuan(), UIHelper.rupiah(b.getHargaJual()), b.getStok()
            });
        }
    }

    private void fillForm() {
        int r = table.getSelectedRow();
        try {
            List<Barang> all = dao.getAll();
            String id = tableModel.getValueAt(r, 0).toString();
            Barang found = all.stream().filter(b -> b.getIdBarang().equals(id)).findFirst().orElse(null);
            if (found == null) return;
            tfId.setText(found.getIdBarang());
            tfNama.setText(found.getNamaBarang());
            tfSatuan.setText(found.getSatuan());
            tfHarga.setText(String.valueOf((long) found.getHargaJual()));
            tfStok.setText(String.valueOf(found.getStok()));
            for (int i = 0; i < cbKategori.getItemCount(); i++) {
                if (cbKategori.getItemAt(i).getIdKategori() == found.getIdKategori()) {
                    cbKategori.setSelectedIndex(i);
                    break;
                }
            }
            btnSimpan.setEnabled(false);
            btnUpdate.setEnabled(true);
            btnHapus.setEnabled(true);
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private boolean validInput() {
        if (tfNama.getText().trim().isEmpty() || tfSatuan.getText().trim().isEmpty()
                || tfHarga.getText().trim().isEmpty() || tfStok.getText().trim().isEmpty()
                || cbKategori.getSelectedItem() == null) {
            err("Semua field wajib diisi!");
            return false;
        }
        try {
            Double.parseDouble(tfHarga.getText().trim());
            Integer.parseInt(tfStok.getText().trim());
        } catch (NumberFormatException ex) {
            err("Harga dan Stok harus berupa angka!");
            return false;
        }
        return true;
    }

    private Barang fromForm() {
        Kategori k = (Kategori) cbKategori.getSelectedItem();
        Barang b = new Barang();
        b.setIdBarang(tfId.getText().trim());
        b.setIdKategori(k.getIdKategori());
        b.setNamaBarang(tfNama.getText().trim());
        b.setSatuan(tfSatuan.getText().trim());
        b.setHargaJual(Double.parseDouble(tfHarga.getText().trim()));
        b.setStok(Integer.parseInt(tfStok.getText().trim()));
        return b;
    }

    private void doInsert() {
        if (!validInput()) return;
        try {
            Barang b = fromForm();
            b.setIdBarang(dao.generateNextId());
            dao.insert(b);
            ok("Barang berhasil disimpan!");
            resetForm();
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void doUpdate() {
        if (!validInput()) return;
        try {
            dao.update(fromForm());
            ok("Barang berhasil diperbarui!");
            resetForm();
        } catch (SQLException ex) {
            err(ex.getMessage());
        }
    }

    private void doDelete() {
        String id = tfId.getText();
        if (id.isEmpty()) return;
        if (JOptionPane.showConfirmDialog(this, "Hapus barang " + id + "?", "Konfirmasi",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            dao.delete(id);
            ok("Barang berhasil dihapus!");
            resetForm();
        } catch (SQLException ex) {
            err("Gagal hapus (mungkin sudah memiliki transaksi): " + ex.getMessage());
        }
    }

    private void resetForm() {
        tfId.setText(""); tfNama.setText(""); tfSatuan.setText("");
        tfHarga.setText(""); tfStok.setText(""); tfSearch.setText("");
        if (cbKategori.getItemCount() > 0) cbKategori.setSelectedIndex(0);
        btnSimpan.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnHapus.setEnabled(false);
        table.clearSelection();
        loadTable();
    }

    private void ok(String m) { JOptionPane.showMessageDialog(this, m, "Sukses", JOptionPane.INFORMATION_MESSAGE); }
    private void err(String m) { JOptionPane.showMessageDialog(this, m, "Error", JOptionPane.ERROR_MESSAGE); }
}
