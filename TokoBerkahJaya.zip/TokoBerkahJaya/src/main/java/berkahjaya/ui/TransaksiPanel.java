package berkahjaya.ui;

import berkahjaya.dao.BarangDAO;
import berkahjaya.dao.CustomerDAO;
import berkahjaya.dao.PenjualanDAO;
import berkahjaya.model.Barang;
import berkahjaya.model.Customer;
import berkahjaya.model.Penjualan;
import berkahjaya.model.User;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.sql.SQLException;
import java.util.Date;

public class TransaksiPanel extends JPanel {

    private final User user;
    private final BarangDAO barangDAO = new BarangDAO();
    private final CustomerDAO customerDAO = new CustomerDAO();
    private final PenjualanDAO penjualanDAO = new PenjualanDAO();

    private JComboBox<Customer> cbCustomer;
    private JComboBox<Barang> cbBarang;
    private JTextField tfHarga, tfStok, tfJumlah, tfTotal;
    private JButton btnSimpan, btnBatal;
    private JLabel lblStatus;

    public TransaksiPanel(User user) {
        this.user = user;
        setBackground(UIHelper.C_BG);
        setLayout(new BorderLayout());
        build();
        loadData();
    }

    private void build() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(UIHelper.C_BG);
        wrapper.setBorder(new EmptyBorder(30, 60, 30, 60));
        GridBagConstraints wc = new GridBagConstraints();
        wc.fill = GridBagConstraints.HORIZONTAL;
        wc.weightx = 1;

        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 240)));

        JPanel header = new JPanel();
        header.setBackground(UIHelper.C_NAVY);
        header.setBorder(new EmptyBorder(16, 24, 16, 24));
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("FORM TRANSAKSI PENJUALAN");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Input data transaksi dengan lengkap");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(new Color(160, 190, 240));
        header.add(title); header.add(sub);
        card.add(header, BorderLayout.NORTH);

        JPanel body = new JPanel(new GridBagLayout());
        body.setBackground(Color.WHITE);
        body.setBorder(new EmptyBorder(25, 30, 25, 30));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(8, 6, 8, 6);

        g.gridx = 0; g.gridy = 0; g.weightx = 0;
        body.add(label("Customer *"), g);
        g.gridx = 1; g.weightx = 1; g.gridwidth = 3;
        cbCustomer = new JComboBox<>();
        body.add(cbCustomer, g);
        g.gridwidth = 1;

        g.gridx = 0; g.gridy = 1; g.weightx = 0;
        body.add(label("Barang *"), g);
        g.gridx = 1; g.weightx = 1; g.gridwidth = 3;
        cbBarang = new JComboBox<>();
        body.add(cbBarang, g);
        g.gridwidth = 1;

        g.gridx = 0; g.gridy = 2; g.weightx = 0;
        body.add(label("Harga Jual"), g);
        g.gridx = 1; g.weightx = 0.5;
        tfHarga = infoField();
        body.add(tfHarga, g);
        g.gridx = 2; g.weightx = 0;
        body.add(label("Stok Tersedia"), g);
        g.gridx = 3; g.weightx = 0.3;
        tfStok = infoField();
        body.add(tfStok, g);

        g.gridx = 0; g.gridy = 3; g.weightx = 0;
        body.add(label("Jumlah Beli *"), g);
        g.gridx = 1; g.weightx = 0.3;
        tfJumlah = new JTextField();
        tfJumlah.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tfJumlah.setHorizontalAlignment(JTextField.CENTER);
        body.add(tfJumlah, g);

        g.gridx = 0; g.gridy = 4; g.gridwidth = 4; g.weightx = 1;
        lblStatus = new JLabel("Pilih barang untuk melihat info stok");
        lblStatus.setOpaque(true);
        lblStatus.setBackground(new Color(248, 251, 255));
        lblStatus.setBorder(new EmptyBorder(10, 14, 10, 14));
        body.add(lblStatus, g);

        g.gridx = 0; g.gridy = 5; g.gridwidth = 1; g.weightx = 0;
        JLabel lTotal = new JLabel("TOTAL BAYAR");
        lTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lTotal.setForeground(UIHelper.C_NAVY);
        body.add(lTotal, g);
        g.gridx = 1; g.weightx = 1; g.gridwidth = 3;
        tfTotal = new JTextField();
        tfTotal.setEditable(false);
        tfTotal.setBackground(UIHelper.C_NAVY);
        tfTotal.setForeground(Color.WHITE);
        tfTotal.setFont(new Font("Segoe UI", Font.BOLD, 22));
        tfTotal.setHorizontalAlignment(JTextField.RIGHT);
        tfTotal.setBorder(new EmptyBorder(10, 14, 10, 14));
        body.add(tfTotal, g);
        g.gridwidth = 1;

        g.gridx = 0; g.gridy = 6; g.gridwidth = 4;
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        btnRow.setOpaque(false);
        btnRow.setBorder(new EmptyBorder(15, 0, 0, 0));
        btnSimpan = bigBtn("SIMPAN TRANSAKSI", UIHelper.C_NAVY);
        btnBatal = bigBtn("BATAL", UIHelper.C_RED);
        btnRow.add(btnSimpan); btnRow.add(btnBatal);
        body.add(btnRow, g);

        card.add(body, BorderLayout.CENTER);
        wrapper.add(card, wc);
        add(wrapper, BorderLayout.CENTER);

        cbBarang.addActionListener(e -> updateBarangInfo());
        tfJumlah.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { hitungTotal(); }
            public void removeUpdate(DocumentEvent e) { hitungTotal(); }
            public void changedUpdate(DocumentEvent e) { }
        });
        btnSimpan.addActionListener(e -> doSimpan());
        btnBatal.addActionListener(e -> resetForm());
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(new Color(60, 70, 90));
        return l;
    }

    private JTextField infoField() {
        JTextField f = new JTextField();
        f.setEditable(false);
        f.setFont(new Font("Segoe UI", Font.BOLD, 13));
        f.setBackground(new Color(248, 249, 252));
        f.setBorder(new EmptyBorder(8, 10, 8, 10));
        return f;
    }

    private JButton bigBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(200, 44));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void loadData() {
        try {
            cbCustomer.removeAllItems();
            for (Customer c : customerDAO.getAll()) cbCustomer.addItem(c);
            cbBarang.removeAllItems();
            for (Barang b : barangDAO.getAll()) cbBarang.addItem(b);
            if (cbBarang.getItemCount() > 0) cbBarang.setSelectedIndex(0);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateBarangInfo() {
        Barang b = (Barang) cbBarang.getSelectedItem();
        if (b == null) return;
        tfHarga.setText(UIHelper.rupiah(b.getHargaJual()));
        tfStok.setText(String.valueOf(b.getStok()));

        if (b.getStok() == 0) {
            lblStatus.setText("STOK HABIS — Transaksi tidak bisa dilakukan!");
            lblStatus.setForeground(UIHelper.C_RED);
        } else if (b.getStok() <= 5) {
            lblStatus.setText("Stok menipis! Tersisa " + b.getStok() + " unit");
            lblStatus.setForeground(UIHelper.C_ORANGE);
        } else {
            lblStatus.setText("Stok tersedia: " + b.getStok() + " unit — siap transaksi");
            lblStatus.setForeground(UIHelper.C_GREEN);
        }
        hitungTotal();
    }

    private void hitungTotal() {
        try {
            Barang b = (Barang) cbBarang.getSelectedItem();
            if (b == null || tfJumlah.getText().trim().isEmpty()) {
                tfTotal.setText("");
                return;
            }
            int jml = Integer.parseInt(tfJumlah.getText().trim());
            tfTotal.setText(UIHelper.rupiah(b.getHargaJual() * jml));
        } catch (NumberFormatException ex) {
            tfTotal.setText("(angka tidak valid)");
        }
    }

    private void doSimpan() {
        Customer sc = (Customer) cbCustomer.getSelectedItem();
        Barang sb = (Barang) cbBarang.getSelectedItem();
        if (sc == null) { warn("Pilih customer!"); return; }
        if (sb == null) { warn("Pilih barang!"); return; }
        if (tfJumlah.getText().trim().isEmpty()) { warn("Masukkan jumlah beli!"); return; }

        int jml;
        try {
            jml = Integer.parseInt(tfJumlah.getText().trim());
            if (jml <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            warn("Jumlah beli harus angka positif!");
            return;
        }
        if (jml > sb.getStok()) {
            warn("Stok tidak mencukupi! Sisa stok: " + sb.getStok());
            return;
        }

        double total = sb.getHargaJual() * jml;
        int cf = JOptionPane.showConfirmDialog(this,
                "Customer : " + sc.getNamaCustomer() + "\n" +
                "Barang   : " + sb.getNamaBarang() + "\n" +
                "Jumlah   : " + jml + " " + sb.getSatuan() + "\n" +
                "Total    : " + UIHelper.rupiah(total) + "\n\nLanjutkan transaksi?",
                "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (cf != JOptionPane.YES_OPTION) return;

        try {
            Penjualan p = new Penjualan(new Date(), sc.getIdCustomer(), sb.getIdBarang(), jml, total, user.getIdUser());
            penjualanDAO.simpanTransaksi(p);
            JOptionPane.showMessageDialog(this,
                    "Transaksi berhasil!\nSisa stok: " + (sb.getStok() - jml) + " unit",
                    "Berhasil", JOptionPane.INFORMATION_MESSAGE);
            resetForm();
            loadData();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Transaksi gagal!\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void resetForm() {
        if (cbCustomer.getItemCount() > 0) cbCustomer.setSelectedIndex(0);
        if (cbBarang.getItemCount() > 0) cbBarang.setSelectedIndex(0);
        tfJumlah.setText("");
        tfTotal.setText("");
        lblStatus.setText("Pilih barang untuk melihat info stok");
        lblStatus.setForeground(new Color(100, 110, 130));
    }

    private void warn(String m) { JOptionPane.showMessageDialog(this, m, "Validasi", JOptionPane.WARNING_MESSAGE); }
}
