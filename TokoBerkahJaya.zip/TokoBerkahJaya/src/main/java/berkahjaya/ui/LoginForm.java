package berkahjaya.ui;

import berkahjaya.dao.UserDAO;
import berkahjaya.model.User;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class LoginForm extends JFrame {

    private JTextField tfUser;
    private JPasswordField tfPass;
    private JLabel lblErr;
    private JButton btnLogin;

    public LoginForm() {
        setTitle("Login - Toko Berkah Jaya");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 480);
        setLocationRelativeTo(null);
        setResizable(false);
        build();
    }

    private void build() {
        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBackground(Color.WHITE);
        main.setBorder(new EmptyBorder(40, 40, 30, 40));

        JLabel title = new JLabel("BERKAH JAYA", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(UIHelper.C_NAVY);
        title.setAlignmentX(0.5f);

        JLabel sub = new JLabel("Sistem Manajemen Penjualan", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(UIHelper.C_TEXT_MUTED);
        sub.setAlignmentX(0.5f);

        tfUser = new JTextField();
        tfPass = new JPasswordField();
        styleField(tfUser);
        styleField(tfPass);

        btnLogin = new JButton("Sign In");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBackground(UIHelper.C_NAVY);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));

        lblErr = new JLabel(" ", SwingConstants.CENTER);
        lblErr.setForeground(UIHelper.C_RED);
        lblErr.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblErr.setAlignmentX(0.5f);

        JLabel demoHint = new JLabel("Demo Admin: admin / admin123", SwingConstants.CENTER);
        demoHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        demoHint.setForeground(UIHelper.C_TEXT_MUTED);
        demoHint.setAlignmentX(0.5f);

        JLabel demoHint2 = new JLabel("Demo Kasir: kasir / kasir123", SwingConstants.CENTER);
        demoHint2.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        demoHint2.setForeground(UIHelper.C_TEXT_MUTED);
        demoHint2.setAlignmentX(0.5f);

        main.add(title);
        main.add(Box.createVerticalStrut(4));
        main.add(sub);
        main.add(Box.createVerticalStrut(30));
        main.add(labelFor("Username"));
        main.add(tfUser);
        main.add(Box.createVerticalStrut(16));
        main.add(labelFor("Password"));
        main.add(tfPass);
        main.add(Box.createVerticalStrut(22));
        main.add(btnLogin);
        main.add(Box.createVerticalStrut(10));
        main.add(lblErr);
        main.add(Box.createVerticalStrut(16));
        main.add(demoHint);
        main.add(demoHint2);

        setContentPane(main);

        ActionListener doLogin = e -> login();
        btnLogin.addActionListener(doLogin);
        tfPass.addActionListener(doLogin);
    }

    private JLabel labelFor(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(UIHelper.C_TEXT_MUTED);
        l.setAlignmentX(0f);
        return l;
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 215, 225), 1, true),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        field.setAlignmentX(0f);
    }

    private void login() {
        String u = tfUser.getText().trim();
        String p = new String(tfPass.getPassword());

        if (u.isEmpty() || p.isEmpty()) {
            lblErr.setText("Username dan password wajib diisi!");
            return;
        }

        btnLogin.setEnabled(false);
        btnLogin.setText("Memproses...");
        lblErr.setText(" ");

        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                return new UserDAO().login(u, p);
            }

            @Override
            protected void done() {
                btnLogin.setEnabled(true);
                btnLogin.setText("Sign In");
                try {
                    User user = get();
                    if (user != null) {
                        dispose();
                        new MainFrame(user).setVisible(true);
                    } else {
                        lblErr.setText("Username atau password salah!");
                        tfPass.setText("");
                    }
                } catch (Exception ex) {
                    lblErr.setText("Koneksi database gagal!");
                    JOptionPane.showMessageDialog(LoginForm.this,
                            "Gagal terhubung ke database:\n" + ex.getCause(),
                            "Connection Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }
}
