package berkahjaya.ui;

import berkahjaya.dao.UserDAO;
import berkahjaya.model.User;
import berkahjaya.util.UIHelper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {

    private final User user;
    private final JPanel contentPanel;
    private final CardLayout cardLayout;

    public MainFrame(User user) {
        this.user = user;
        setTitle("Toko Berkah Jaya - Sistem Kasir");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 680);
        setMinimumSize(new Dimension(950, 600));
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(UIHelper.C_BG);

        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);

        // Panel-panel utama
        contentPanel.add(new DashboardPanel(user), "dashboard");
        contentPanel.add(new BarangPanel(), "barang");
        contentPanel.add(new CustomerPanel(), "customer");
        contentPanel.add(new TransaksiPanel(user), "transaksi");
        contentPanel.add(new LaporanPanel(), "laporan");

        cardLayout.show(contentPanel, "dashboard");
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UIHelper.C_NAVY);
        sidebar.setPreferredSize(new Dimension(220, 0));

        JLabel brand = new JLabel("  BERKAH JAYA");
        brand.setFont(new Font("Segoe UI", Font.BOLD, 18));
        brand.setForeground(Color.WHITE);
        brand.setBorder(new EmptyBorder(25, 5, 5, 5));

        JLabel brandSub = new JLabel("  Smart Retail System");
        brandSub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        brandSub.setForeground(new Color(160, 190, 240));
        brandSub.setBorder(new EmptyBorder(0, 5, 25, 5));

        sidebar.add(brand);
        sidebar.add(brandSub);

        sidebar.add(navButton("Dashboard", "dashboard"));
        sidebar.add(navButton("Data Barang", "barang"));
        sidebar.add(navButton("Data Customer", "customer"));
        sidebar.add(navButton("Transaksi", "transaksi"));
        sidebar.add(navButton("Laporan", "laporan"));

        sidebar.add(Box.createVerticalGlue());

        JPanel userBox = new JPanel(new BorderLayout(10, 0));
        userBox.setOpaque(false);
        userBox.setBorder(new EmptyBorder(14, 16, 14, 16));

        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setOpaque(false);
        JLabel nameLbl = new JLabel(user.getNamaLengkap());
        nameLbl.setForeground(Color.WHITE);
        nameLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        JLabel levelLbl = new JLabel(user.isAdmin() ? "Admin" : "Kasir");
        levelLbl.setForeground(new Color(160, 190, 240));
        levelLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        info.add(nameLbl);
        info.add(levelLbl);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBackground(UIHelper.C_RED);
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> doLogout());

        userBox.add(info, BorderLayout.CENTER);
        userBox.add(logoutBtn, BorderLayout.EAST);
        sidebar.add(userBox);

        return sidebar;
    }

    private JButton navButton(String label, String cardName) {
        JButton btn = new JButton(label);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(UIHelper.C_NAVY);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(12, 20, 12, 20));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(0f);

        // Khusus kasir: hanya tampilkan menu operasional (sesuai laporan BAB II poin 10-12)
        if (!user.isAdmin() && cardName.equals("barang")) {
            // Kasir tetap bisa melihat data barang (read-only) sesuai laporan,
            // tapi tidak ada hak hapus -> tetap ditampilkan, validasi di panel jika perlu.
        }

        btn.addActionListener(e -> cardLayout.show(contentPanel, cardName));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(35, 75, 145));
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(UIHelper.C_NAVY);
            }
        });
        return btn;
    }

    private void doLogout() {
        int cf = JOptionPane.showConfirmDialog(this, "Yakin ingin logout?", "Konfirmasi",
                JOptionPane.YES_NO_OPTION);
        if (cf == JOptionPane.YES_OPTION) {
            try {
                new UserDAO().logout(user.getIdUser());
            } catch (Exception ignored) { }
            dispose();
            new LoginForm().setVisible(true);
        }
    }
}
